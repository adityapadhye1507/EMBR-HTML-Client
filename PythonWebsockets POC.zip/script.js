var connection;

$(document).ready(function(){
    /*var url = "DEMO.embr";
        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'text',
            success: callback,
        });*/
});

/*function callback( data ){
    script = data;
    console.log(script, "Done fetching data!!");
}*/

function connect(){
    
    if(connection == undefined || connection.readyState!=1){
        
        connection = new WebSocket('ws://localhost:1337/');
    
        connection.onopen = function() {
            console.log("Connection open now, Try to send some data!!");
        };

        // Log errors
        connection.onerror = function (error) {
            console.log('WebSocket Error!!!');
            console.dir(error);
        };

        // Log messages from the server
        connection.onmessage = function (e) {
          console.log('OMG Server responded!!!', e.data);
        };

        connection.onclose = function(e){
            console.log("Connection Closed now!! bye bye!!");
        }
    }
}

function animateBen(){

    var text = $("#embrScript")[0].value;
    
    if(connection){
        console.log("Sending EMBR Script!!");
        if(text != ""){
            connection.send(text);
        } else{
            console.log("No data in text area to send!!");
        }
        
    } else{
        console.log("Not Connected to WS Server!!");
    }
}

function closeConnection(){
    console.log("We want to close the connection!");
    if(connection != undefined || connect.readyState == 1){
        connection.close();
    }
}

function str2ab(str) {
  var buf = new ArrayBuffer(str.length*2); // 2 bytes for each char
  var bufView = new Uint16Array(buf);
  for (var i=0, strLen=str.length; i<strLen; i++) {
    bufView[i] = str.charCodeAt(i);
  }
  return buf;
}

